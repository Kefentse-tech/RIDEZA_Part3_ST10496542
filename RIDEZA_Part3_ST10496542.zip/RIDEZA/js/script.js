
document.addEventListener("DOMContentLoaded", function () {

    // Select the booking form and message area
    const bookingForm = document.getElementById("booking-form");
    const formMessage = document.getElementById("form-message");

    // Set the minimum booking date to today
    const dateInput = document.getElementById("date");

    if (dateInput) {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, "0");
        const day = String(today.getDate()).padStart(2, "0");

        dateInput.min = `${year}-${month}-${day}`;
    }

    // Booking form validation
    if (bookingForm) {

        bookingForm.addEventListener("submit", function (event) {

            // Prevent the form from submitting automatically
            event.preventDefault();

            // Check that all required fields are completed
            if (!bookingForm.checkValidity()) {
                bookingForm.reportValidity();

                formMessage.textContent =
                    "Please complete all required fields correctly.";

                formMessage.style.color = "red";
                return;
            }

            // Check the South African phone number
            const phone = document.getElementById("phone").value.trim();
            const phonePattern = /^(\+27|0)[0-9]{9}$/;

            if (!phonePattern.test(phone)) {
                formMessage.textContent =
                    "Please enter a valid South African phone number.";

                formMessage.style.color = "red";
                return;
            }

            // Check that the selected date is not in the past
            const selectedDate = new Date(dateInput.value + "T00:00:00");
            const currentDate = new Date();
            currentDate.setHours(0, 0, 0, 0);

            if (selectedDate < currentDate) {
                formMessage.textContent =
                    "Please select today or a future date.";

                formMessage.style.color = "red";
                return;
            }

            // Display a confirmation message
            formMessage.textContent =
                "Your booking request has been completed successfully!";

            formMessage.style.color = "green";

            // Clear the form after successful validation
            bookingForm.reset();

        });

    }

            
    // Contact form validation
    const contactForm = document.getElementById("contact-form");

    if (contactForm) {

        contactForm.addEventListener("submit", function (event) {

            event.preventDefault();

            const contactName = document.getElementById("contactName").value.trim();
            const contactEmail = document.getElementById("contactEmail").value.trim();
            const contactMessage = document.getElementById("contactMessage").value.trim();

            const messageDisplay = document.getElementById("contact-form-message");

            if (contactName === "" || contactEmail === "" || contactMessage === "") {

                messageDisplay.textContent = "Please complete all fields before sending your message.";
                messageDisplay.style.color = "red";

                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailPattern.test(contactEmail)) {

                messageDisplay.textContent = "Please enter a valid email address.";
                messageDisplay.style.color = "red";

                return;
            }

            messageDisplay.textContent = "Your message has been submitted successfully!";
            messageDisplay.style.color = "green";

            contactForm.reset();

        });

    }
        
    // Gallery lightbox functionality
    const galleryImages = document.querySelectorAll(".gallery-image");
    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightbox-image");
    const closeLightbox = document.getElementById("close-lightbox");

    if (galleryImages.length > 0 && lightbox && lightboxImage && closeLightbox) {

        // Open an enlarged image when clicked
        galleryImages.forEach(function (image) {

            image.addEventListener("click", function () {

                lightboxImage.src = image.src;
                lightboxImage.alt = image.alt;

                lightbox.hidden = false;

            });

        });

        // Close the enlarged image
        closeLightbox.addEventListener("click", function () {

            lightbox.hidden = true;
            lightboxImage.src = "";

        });

        // Close when clicking outside the image
        lightbox.addEventListener("click", function (event) {

            if (event.target === lightbox) {
                lightbox.hidden = true;
                lightboxImage.src = "";
            }

        });

        // Close using the Escape key
        document.addEventListener("keydown", function (event) {

            if (event.key === "Escape" && !lightbox.hidden) {
                lightbox.hidden = true;
                lightboxImage.src = "";
            }

        });

    }
    
    // Services search functionality
    const serviceSearch = document.getElementById("service-search");
    const serviceCards = document.querySelectorAll(".service-card");
    const searchMessage = document.getElementById("search-message");

    if (serviceSearch && serviceCards.length > 0) {

        serviceSearch.addEventListener("input", function () {

            const searchTerm = serviceSearch.value.toLowerCase().trim();
            let visibleServices = 0;

            serviceCards.forEach(function (card) {

                const serviceName = card.textContent.toLowerCase();

                if (serviceName.includes(searchTerm)) {
                    card.hidden = false;
                    visibleServices++;
                } else {
                    card.hidden = true;
                }

            });

            if (searchTerm === "") {
                searchMessage.textContent = "";
            } else if (visibleServices === 0) {
                searchMessage.textContent = "No matching services found.";
            } else {
                searchMessage.textContent =
                    visibleServices + " service(s) found.";
            }

        });

    }

               
    // Back to Top button functionality
    const backToTopButton = document.getElementById("back-to-top");

    if (backToTopButton) {

        // Show the button after scrolling down
        window.addEventListener("scroll", function () {

            if (window.scrollY > 300) {
                backToTopButton.style.display = "block";
            } else {
                backToTopButton.style.display = "none";
            }

        });

        // Return to the top when clicked
        backToTopButton.addEventListener("click", function () {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        });

    }


});

